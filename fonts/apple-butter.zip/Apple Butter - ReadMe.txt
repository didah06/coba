APPLE BUTTER
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Strawberry-rhubarb preserves, apple butter, and a creamy potato and macaroni soup are my three favorite food-related memories from early childhood, and all three were the work of Etta Collins, my great-grandmother. Something about the look of this month's font got me thinking of those days.

Fans of the Fontworks will no doubt notice that this is the second font I've made with a "jar of preserves" motif. Some kind of nostalgic rebellion against being diabetic, maybe? I have no idea. This one lacks the mad charm of its predecessor, but has a saner, calmer charm all its own.

Apple Butter is a full-keyboard set with a few selected extended characters (like smart quotes, dashes and the all-important � needed for words like Pok�thulhu and Clich�). This new, revised version 2.0 adds a Euro symbol and some more accents (someday, I'll get around to adding them all). Enjoy!

This font is copyright 2002,2009 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for private use only. Contact me at sjohn@cumberlandgames.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 2.0